//
//  ContentView.swift
//  AW_test
//
//  Created by Fettah KIRAN on 10/28/24.
//

import SwiftUI
import WatchConnectivity
import UIKit

struct ContentView: View {
    var watchConnector = WatchConnector()
    
    var body: some View {
  
        
        VStack(spacing: 20) {
            Text("Watch Connectivity Test App")
                .font(.largeTitle)
                .bold()
                .padding()
                .multilineTextAlignment(.center)
            
            Text("Click Watch button to send \n the current time to your watch")
                .font(.headline)
                .foregroundColor(.white)
                .multilineTextAlignment(.center)
                .padding()
                .background(
                    LinearGradient(gradient: Gradient(colors: [.red, .orange]), startPoint: .topLeading, endPoint: .bottomTrailing)
                        .shadow(color: .gray.opacity(0.4), radius: 8, x: 4, y: 4)
                )
            
            Button(action: sendToWatch) {
                Image(systemName: "applewatch")
                    .font(.system(size: 40))
                    .foregroundColor(.white)
                    .padding()
                    .background(
                        RadialGradient(gradient: Gradient(colors: [.purple, .black]), center: .center, startRadius: 5, endRadius: 50)
                            .clipShape(Circle())
                    )
                    .overlay(
                        Circle()
                            .stroke(Color.white.opacity(0.6), lineWidth: 2)
                    )
                    .shadow(color: .black.opacity(0.3), radius: 10, x: 0, y: 6)
            }
        }
        .padding()
        .background(Color.black.opacity(0.3).ignoresSafeArea())
        .cornerRadius(12)

    }
    
    
    
    func sendToWatch() {
        let message = ["message": "Received at \(Date().formatted(.dateTime.hour().minute().second()))!"]
        print(message["message"] as Any)
        

        if WCSession.default.isReachable {
            // Send the message first
            WCSession.default.sendMessage(message, replyHandler: nil) { error in
                print("Failed to send message to Watch: \(error.localizedDescription)")}

        } else {
            print("Watch is not reachable.")
        }

    }
}

#Preview {
    ContentView()
}
