//
//  AW_testApp.swift
//  AW_test
//
//  Created by Fettah KIRAN on 10/30/24.
//

import SwiftUI

@main
struct WC_testApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
