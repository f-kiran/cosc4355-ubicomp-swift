# Debugging the connection issue

If the connection is not working, but you're sure that the code is all good.
Then follow the suggested steps below

1 - Erase All Content and Settings
2 - Restart the simulator for iphone and watch
3 - Restart Xcode
4 - Finally restarting your machine could be the solution. 

