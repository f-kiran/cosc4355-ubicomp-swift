//
//  AW_testApp.swift
//  AW_test Watch App
//
//  Created by Fettah KIRAN on 10/30/24.
//

import SwiftUI

@main
struct WC_test_Watch_AppApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
