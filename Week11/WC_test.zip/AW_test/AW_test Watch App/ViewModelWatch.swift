//
//  ViewModelWatch.swift
//  Week11_demowatch Watch App
//
//  Created by Fettah KIRAN on 10/27/24.
//

import Foundation


// 12

import WatchConnectivity // Import WatchConnectivity framework for communication between Apple Watch and iPhone
import SwiftUI


class ViewModelWatch: NSObject, WCSessionDelegate,ObservableObject{
    var session: WCSession
    
    @Published var messageText = "Waiting for the current time" // Published property for message text

    
    // initial prperties
    init(session: WCSession = .default){
        self.session = session
        super.init()
        self.session.delegate = self
        session.activate()
    }
    
    // MARK: - WCSessionDelegate Methods
    
    // Delegate function
    func session(_ session: WCSession, activationDidCompleteWith activationState: WCSessionActivationState, error: Error?) {
        
    }
    // Delegate function
    func session(_ session: WCSession, didReceiveMessage message: [String : Any]) {
        DispatchQueue.main.async {
            print(message["message"] as Any)
            self.messageText = message["message"] as? String ?? "Unknown" // Update messageText property
        }
    }
    
}


