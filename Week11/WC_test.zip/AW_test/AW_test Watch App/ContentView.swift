//
//  ContentView.swift
//  WC Watch App
//
//  Created by Fettah KIRAN on 10/27/24.
//

import SwiftUI

struct ContentView: View {
    @ObservedObject var model = ViewModelWatch()
    var body: some View {
        VStack {
            Text(model.messageText)
                .multilineTextAlignment(.center)
                .foregroundColor(.white)
                .font(.custom("SF Pro Display", size: 24))
                .bold()
                .padding()
                .background(
                    LinearGradient(gradient: Gradient(colors: [.red, .orange]), startPoint: .topLeading, endPoint: .bottomTrailing)
                        .cornerRadius(12)
                        .shadow(color: .gray.opacity(0.4), radius: 8, x: 4, y: 4)
                )
                .overlay(
                    RoundedRectangle(cornerRadius: 12)
                        .stroke(Color.white.opacity(0.7), lineWidth: 1)
                )
                .scaleEffect(1.05)
        }
        .padding()
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
